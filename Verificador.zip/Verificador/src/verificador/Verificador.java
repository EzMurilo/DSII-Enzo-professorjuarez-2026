/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package verificador;

import javax.swing.JOptionPane;

public class Verificador {
    public static void main(String[] args) {
        String st = "INFORME SEU SALARIO:";
        st = JOptionPane.showInputDialog(null, st);
        String status;
        // Conversão de String para int
        float saldo = Float.parseFloat(st);
        
        
        if(saldo > 0){
            status = "Positivo";
        }
        else if(saldo < 0){
            status = "Negativo";
        }
        else{
            status = "Zerado";
        }
        st = "Seu salario esta: "+ status;
        JOptionPane.showMessageDialog(null, st, "MENSAGEM", 1);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package seletor;

import javax.swing.JOptionPane;

public class Seletor {
    public static void main(String[] args) {
        String st = "Canais:\n" +"2 - Cultura\n" +"4 - SBT\n" +"5 - Globo\n" +"7 - Record\n" +"9 - Manchete\n" +"11 - Gazeta\n" +"13 - Bandeirantes" +"\nInforme qual canal deseja:";
        st = JOptionPane.showInputDialog(null, st);
        int canal = Integer.parseInt(st);
        
        switch (canal) {
            case 2:
                st = "CANAL CULTURA";
                break;
            case 4:
                st = "SBT";
                break;
            case 5:
                st = "GLOBO";
                break;
            case 7:
                st = "RECORD";
                break;
            case 9:
                st = "MANCHETE";
                break;
            case 11:
                st = "GAZETA";
                break;
            case 13:
                st = "BANDEIRANTES";
                break;
            default:
                JOptionPane.showMessageDialog(null, "Canal invalido", "ERRO", 0);
                System.exit(0);
                break;
        }
        
        st = "VOCÊ ESCOLHEU CANAL " + st;
        JOptionPane.showMessageDialog(null, st, "MENSAGEM", 1);
    }
    
}
